﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking_Application
{
    class Account_Type
    {
        public static int Current_Account = 1;
        public static int Savings_Account = 2;
    }
}
